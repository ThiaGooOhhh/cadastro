/// <reference types="node" />

import express, { Request, Response } from 'express';
import cors from 'cors';
import { createClient } from '@supabase/supabase-js';
import { GoogleGenAI, Type } from "@google/genai";
import 'dotenv/config';
import pg from 'pg';

// --- Types ---
interface Address {
  street: string;
  number: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
  zip: string;
}

interface Client {
  id: number;
  name: string;
  phone: string;
  email: string;
  cpf: string;
  address: Address;
}

interface Visit {
    id: number;
    clientId: number;
    clientName: string;
    date: string;
    subject: string;
    status: 'Agendada' | 'Concluída' | 'Cancelada';
}

// --- Configuração ---
const app: express.Application = express();
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// --- Conexão e Variáveis de Ambiente ---
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const apiKey = process.env.API_KEY;
const dbConnectionString = process.env.DATABASE_URL;

if (!supabaseUrl || !supabaseKey || !apiKey || !dbConnectionString) {
    console.error("Variáveis de ambiente essenciais (SUPABASE_URL, SUPABASE_KEY, API_KEY, DATABASE_URL) não foram definidas.");
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);
const ai = new GoogleGenAI({apiKey: apiKey});

// --- Tratamento de Erros Genérico ---
const handleError = (res: Response, error: any, message = "Ocorreu um erro interno no servidor.") => {
  console.error(error);
  const errorMessage = error instanceof Error ? error.message : String(error);
  res.status(500).json({ message, error: errorMessage });
};

// --- Rotas da API (Clientes, Visitas, IA) ---

// CLIENTES
app.get('/api/clients', async (req: Request, res: Response) => {
  try {
    const { data, error } = await supabase.from('clients').select('*').order('name', { ascending: true });
    if (error) throw error;
    res.json(data);
  } catch (error) {
    handleError(res, error, "Falha ao buscar clientes.");
  }
});

type CreateClientPayload = Omit<Client, 'id'>;
app.post('/api/clients', async (req: Request<{}, any, CreateClientPayload>, res: Response) => {
  try {
    const { data, error } = await supabase.from('clients').insert([req.body]).select();
    if (error) throw error;
    res.status(201).json(data[0]);
  } catch (error) {
    handleError(res, error, "Falha ao criar cliente.");
  }
});

type UpdateClientPayload = Partial<Omit<Client, 'id'>>;
app.put('/api/clients/:id', async (req: Request<{ id: string }, any, UpdateClientPayload>, res: Response) => {
    try {
        const { id } = req.params;
        const { data, error } = await supabase.from('clients').update(req.body).eq('id', id).select();
        if (error) throw error;
        if (!data || data.length === 0) return res.status(404).json({ message: "Cliente não encontrado." });
        res.json(data[0]);
    } catch (error) {
        handleError(res, error, "Falha ao atualizar cliente.");
    }
});

app.delete('/api/clients/:id', async (req: Request<{ id: string }>, res: Response) => {
    try {
        const { id } = req.params;
        const { error } = await supabase.from('clients').delete().eq('id', id);
        if (error) throw error;
        res.status(204).send();
    } catch (error) {
        handleError(res, error, "Falha ao excluir cliente.");
    }
});

// VISITAS
app.get('/api/visits', async (req: Request, res: Response) => {
    try {
      const { data, error } = await supabase.from('visits').select('*').order('date', { ascending: false });
      if (error) throw error;
      res.json(data);
    } catch (error) {
      handleError(res, error, "Falha ao buscar visitas.");
    }
});

type CreateVisitPayload = Omit<Visit, 'id' | 'clientName'>;
app.post('/api/visits', async (req: Request<{}, any, CreateVisitPayload>, res: Response) => {
    try {
      const { clientId } = req.body;
      const { data: clientData, error: clientError } = await supabase
        .from('clients')
        .select('name')
        .eq('id', clientId)
        .single();
      
      if (clientError || !clientData) throw new Error("Cliente associado não encontrado.");

      const visitData = { ...req.body, clientName: clientData.name };
      const { data, error } = await supabase.from('visits').insert([visitData]).select();
      if (error) throw error;
      res.status(201).json(data[0]);
    } catch (error) {
      handleError(res, error, "Falha ao criar visita.");
    }
});

type UpdateVisitPayload = Omit<Visit, 'id' | 'clientName'>;
app.put('/api/visits/:id', async (req: Request<{ id: string }, any, UpdateVisitPayload>, res: Response) => {
    try {
        const { id } = req.params;
        const { clientId } = req.body;

        const { data: clientData, error: clientError } = await supabase
          .from('clients')
          .select('name')
          .eq('id', clientId)
          .single();
      
        if (clientError || !clientData) throw new Error("Cliente associado não encontrado.");

        const visitData = { ...req.body, clientName: clientData.name };

        const { data, error } = await supabase.from('visits').update(visitData).eq('id', id).select();
        if (error) throw error;
        if (!data || data.length === 0) return res.status(404).json({ message: "Visita não encontrada." });
        res.json(data[0]);
    } catch (error) {
        handleError(res, error, "Falha ao atualizar visita.");
    }
});

app.delete('/api/visits/:id', async (req: Request<{ id: string }>, res: Response) => {
    try {
        const { id } = req.params;
        const { error } = await supabase.from('visits').delete().eq('id', id);
        if (error) throw error;
        res.status(204).send();
    } catch (error) {
        handleError(res, error, "Falha ao excluir visita.");
    }
});

// IA
app.post('/api/ai/fill-client', async (req: Request, res: Response) => {
    const prompt = "Gere os dados de um cliente brasileiro fictício completo para um formulário de cadastro. Inclua nome, telefone, email, CPF e endereço completo (rua, número, complemento, bairro, cidade, estado, CEP).";
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING },
                        phone: { type: Type.STRING },
                        email: { type: Type.STRING },
                        cpf: { type: Type.STRING },
                        address: {
                            type: Type.OBJECT,
                            properties: {
                                street: { type: Type.STRING },
                                number: { type: Type.STRING },
                                complement: { type: Type.STRING },
                                neighborhood: { type: Type.STRING },
                                city: { type: Type.STRING },
                                state: { type: Type.STRING },
                                zip: { type: Type.STRING },
                            },
                        },
                    },
                }
            }
        });
        res.json(JSON.parse(response.text));
    } catch (error) {
        handleError(res, error, 'Falha ao gerar dados de cliente com IA.');
    }
});

app.post('/api/ai/generate-subject', async (req: Request<{}, any, { clientName: string }>, res: Response) => {
    const { clientName } = req.body;
    if (!clientName) {
        return res.status(400).json({ message: 'O nome do cliente é obrigatório.' });
    }
    const prompt = `Gere um assunto curto e profissional para uma visita a um cliente chamado ${clientName}. Exemplo: "Reunião de Alinhamento Estratégico" ou "Apresentação de Proposta Comercial". O assunto deve ser conciso e direto, sem aspas ao redor.`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        const generatedSubject = response.text.trim().replace(/^"|"$/g, '');
        res.json({ subject: generatedSubject });
    } catch (error) {
        handleError(res, error, 'Falha ao gerar assunto da visita com IA.');
    }
});

// --- Inicialização do Banco de Dados ---
const initializeDatabase = async () => {
    const { Pool } = pg;
    const pool = new Pool({ connectionString: dbConnectionString });
    const client = await pool.connect();
    try {
        console.log("Verificando schema do banco de dados...");
        const tableCheck = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' AND table_name = 'clients'
      );
    `);

        if (!tableCheck.rows[0].exists) {
            console.log("Tabelas não encontradas. Criando schema...");
            await client.query(`
        CREATE TABLE public.clients (
            id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
            name text NOT NULL,
            phone text,
            email text,
            cpf text,
            address jsonb,
            created_at timestamp with time zone NOT NULL DEFAULT now()
        );

        CREATE TABLE public.visits (
            id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
            client_id bigint NOT NULL,
            client_name text NOT NULL,
            date timestamp with time zone NOT NULL,
            subject text,
            status text,
            created_at timestamp with time zone NOT NULL DEFAULT now(),
            CONSTRAINT visits_client_id_fkey FOREIGN KEY (client_id)
                REFERENCES public.clients (id) ON DELETE CASCADE
        );

        -- Habilita RLS - boa prática do Supabase
        ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
        ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

        -- Políticas que permitem acesso total via service_role (usado no backend)
        CREATE POLICY "Enable all access for service-role"
            ON public.clients FOR ALL
            USING (true)
            WITH CHECK (true);

        CREATE POLICY "Enable all access for service-role"
            ON public.visits FOR ALL
            USING (true)
            WITH CHECK (true);
      `);
            console.log("Schema do banco de dados criado com sucesso.");
        } else {
            console.log("Schema do banco de dados já existe.");
        }
    } finally {
        await client.release();
        await pool.end();
    }
};

// --- Iniciar Servidor ---
const startServer = async () => {
    try {
        await initializeDatabase();
        app.listen(port, () => {
            console.log(`Backend server running on http://localhost:${port}`);
        });
    } catch (error) {
        console.error("Falha ao inicializar o banco de dados. O servidor não será iniciado.", error);
        process.exit(1);
    }
};

startServer();